package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Simple endpoint to demonstrate a checksum (hash) used for integrity verification.
 *
 * Run the app and open:
 *   https://localhost:8443/hash
 *
 * Optional:
 *   https://localhost:8443/hash?data=your+custom+string
 *   https://localhost:8443/verify?data=hello&checksum=<sha256>
 */
@RestController
public class HashController {

    // Change this to your preferred display name for the screenshot.
    private static final String STUDENT_NAME = "Pablo Fajardo";

    @GetMapping("/hash")
    public Map<String, Object> hash(@RequestParam(value = "data", required = false) String data) {
        String unique = UUID.randomUUID().toString();

        // If no input was provided, build a unique data string that includes the student's name.
        String payload = (data == null || data.trim().isEmpty())
                ? "Hello World Check Sum! | student=" + STUDENT_NAME + " | id=" + unique
                : data;

        String checksum = sha256Hex(payload);

        // "Verification" step: recompute and compare
        boolean verified = checksum.equals(sha256Hex(payload));

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("student", STUDENT_NAME);
        response.put("algorithm", "SHA-256");
        response.put("data", payload);
        response.put("checksum", checksum);
        response.put("verified", verified);
        response.put("timestamp", Instant.now().toString());
        return response;
    }

    @GetMapping("/verify")
    public Map<String, Object> verify(
            @RequestParam("data") String data,
            @RequestParam("checksum") String checksum) {

        String computed = sha256Hex(data);
        boolean valid = computed.equalsIgnoreCase(checksum);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("algorithm", "SHA-256");
        response.put("data", data);
        response.put("providedChecksum", checksum);
        response.put("computedChecksum", computed);
        response.put("valid", valid);
        response.put("timestamp", Instant.now().toString());
        return response;
    }

    private static String sha256Hex(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(hash);
        } catch (Exception e) {
            // Wrap as unchecked so the endpoint returns a 500 if something unexpected happens.
            throw new IllegalStateException("Unable to compute SHA-256 hash", e);
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
